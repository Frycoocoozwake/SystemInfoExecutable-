**READING THIS MUST BE DONE BEFORE USE, READ THE WHOLE MANUAL**
Before you use my tool here is basic info:
Run without admin for the basic info of your pc.
Run with admin for Every bit of info, this can take a while because it checks your disk status and NEVER CLOSE THE APP DURING THIS PROCESS. You can close it when at the bottom it says press to continue and when you press a key it ends.
This file is NOT malicious and is harmless if you use it.
This apps intended purpose is to give you all of your systems info quickly without having to type it in with CMD.
The only place you can get this app is from my GitHub, YouTube, or Discord. If you got it off a different website delete it right away and notify me about it.
Thank you for reading this manual, have a nice day fellow PC user!
~!Created by Frycoocoozwake on 1/7/2024 in the .bat format!~